# Wolf
Wolf is a CLI tool to assist and make easy repetitive tasks such as downloading images and unshortening URLs 
