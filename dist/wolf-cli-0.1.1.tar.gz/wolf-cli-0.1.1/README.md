# **Wolf**
## Wolf is a CLI tool to assist and make easy repetitive tasks such as downloading images and URLs unshortening
---
This Project uses code adapted from: [Kevin Tewouda](https://lewoudar.medium.com/click-a-beautiful-python-library-to-write-cli-applications-9c8154847066)
