import typer
from pathlib import Path
from typing import Optional
import json
from yahoo_fin import stock_info

trading_app = typer.Typer()

def get_real_time(symbol):
    symbolTable = stock_info.get_quote_table(symbol)
    data = json.dumps(symbolTable, sort_keys=False, indent=2)
    return data

@trading_app.command()
def real_time_data(symbol: str = typer.Option(..., prompt=True)):
    """
    Get real-time stock-market data
    """
    print(get_real_time(symbol))